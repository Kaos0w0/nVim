local options = {
	showmode 		= false,                    -- With lualine is enough
	showcmd			= false,					-- Display actions on the left corner
	backup			= false,                    -- Don't create a backup file
	clipboard 		= "unnamedplus",            -- Allows neovim to access the system clipboard
--	cmdheight		= 2,                        -- More space in the neovim command line for displaying messages
	completeopt 	= {"menuone", "noselect"},	-- Mostly just for cmp
	conceallevel 	= 0,                        -- So that `` is visible in markdown files
	fileencoding 	= "utf-8",                  -- The encoding written to a file
	hlsearch 		= true,                     -- Highlight all matches on previous search pattern
	ignorecase 		= true,                     -- Ignore case in search patterns
	mouse 			= "a",                      -- Allow the mouse to be used in neovim
	pumheight 		= 10,                       -- Pop up menu height
	showtabline 	= 4,                        -- Always show tabs
	smartcase 		= true,                     -- Smart case
	smartindent 	= true,                     -- Make indenting smarter again
	splitbelow 		= true,                     -- Force all horizontal splits to go below current window
	splitright 		= true,                     -- Force all vertical splits to go to the right of current window
	swapfile 		= false,                    -- Creates a swapfile
	termguicolors 	= true,                     -- Set term gui colors
	timeoutlen 		= 300,                      -- Time to wait for a mapped sequence to complete (in milliseconds)
	undofile 		= true,                     -- Enable persistent undo
	updatetime 		= 300,                      -- Faster completion (4000ms default)
	writebackup 	= false,                    -- If a file is being edited by another program (or was written to file while editing with another program), it is not allowed to be edited
	expandtab 		= true,                     -- Convert tabs to spaces
	shiftwidth 		= 4,                        -- The number of spaces inserted for each indentation
	tabstop 		= 4,                        -- Insert 4 spaces for a tab
	cursorline 		= true,                     -- Highlight the current line
	cursorcolumn 	= true,					 	-- Highlight the current line
	number 			= true,                     -- Set numbered lines
	relativenumber 	= true,                   	-- Set relative numbered lines
	numberwidth 	= 4,                        -- Set number column width to 2 {default 4}	
	signcolumn 		= "yes",                    -- Always show the sign column, otherwise it would shift the text each time
	linebreak 		= true,                     -- Companion to wrap, don't split words
	scrolloff 		= 8,                        -- Minimal number of screen lines to keep above and below the cursor
	sidescrolloff 	= 8,                       	-- Minimal number of screen columns either side of cursor if wrap is `false`
	guifont         = "monospace:h17",          -- The font used in graphical neovim applications
	whichwrap       = "bs<>[]hl",                  -- which "horizontal" keys are allowed to travel to prev/next line
}

for k, v in pairs(options) do
  vim.opt[k] = v
end

-- vim.opt.shortmess = "ilmnrx"                        -- flags to shorten vim messages, see :help 'shortmess'
vim.opt.shortmess:append "c"                           -- don't give |ins-completion-menu| messages
vim.opt.iskeyword:append "-"                           -- hyphenated words recognized by searches
vim.opt.formatoptions:remove({ "c", "r", "o" })        -- don't insert the current comment leader automatically for auto-wrapping comments using 'textwidth', hitting <Enter> in insert mode, or hitting 'o' or 'O' in normal mode.
vim.opt.runtimepath:remove("/usr/share/vim/vimfiles")  -- separate vim plugins from neovim in case vim still in use
