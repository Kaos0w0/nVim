require("bufferline").setup{}
