require('lualine').setup {
	options = { 
		theme = 'gruvbox' 
	}
}
